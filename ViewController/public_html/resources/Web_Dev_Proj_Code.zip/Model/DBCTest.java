package client;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

import java.util.Random;


public class DBCTest {

    /**
     * @param args
     */
    public static void main(String[] args) {
        DBC dbc = new DBC();
        Random r = new Random(System.currentTimeMillis());
        String username="Colin", email="Colinchristie444@gmail.com", password="gfdhsjak1";
        String title="Sample Image", caption="Sample Caption", ext="jpg", session=" ", description="test description";
        String hash=" ", salt=" ";
        int count = 5, offset=0, uid=25;
        
        String q = "SELECT * FROM " +
            "( SELECT rownum rnum, a.* FROM" +
            "( SELECT aid FROM albums " +
            " WHERE user_id="+ uid +
            " ORDER BY aid DESC) a " +
            "WHERE rownum <= "+offset+" + "+count+") WHERE rnum >"+offset;
        try{    
            ResultSet res = dbc.executeQuery(q);
            while (res.next())
                System.out.println(res.getInt(2));
        }
        catch(SQLException e){
            System.out.println("Error getting user photos: " + e);
            System.out.println("With query: " + q);
        }
    }
                
}
